import { Request, Response } from 'express';
import Project from '../models/Project';
import WebsiteGeneration from '../models/WebsiteGeneration';

export class ProjectController {
  static async getProject(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const project = await Project.findById(id).populate('latestGenerationId');
      if (!project) return res.status(404).json({ error: 'Project not found' });
      res.json(project);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }

  static async listProjects(req: Request, res: Response) {
    try {
        // In a real app, filtering by user from auth token would be here
        const projects = await Project.find(); 
        res.json(projects);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
  }

  static async updateProject(req: Request, res: Response) {
      try {
          const { id } = req.params;
          const { name, status } = req.body;
          const project = await Project.findByIdAndUpdate(id, { name, status }, { new: true });
          if (!project) return res.status(404).json({ error: "Project not found" });
          res.json(project);
      } catch (error: any) {
          res.status(500).json({ error: error.message });
      }
  }

  static async saveProjectContent(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const { content } = req.body; // content is the WebsiteStructure
      
      const project = await Project.findById(id);
      if (!project) return res.status(404).json({ error: 'Project not found' });

      if (!project.latestGenerationId) return res.status(400).json({ error: 'No generation found to update' });

      // In a real app, we might create a new version here instead of overwriting.
      // For now, we update the existing generation record or create a new one as "latest"
      // But usually "WebsiteGeneration" is the AI output. User edits should maybe be stored in Project or a separate "Version" model.
      // To keep it simple and fix the "Export" issue, we will update the `output` of the `latestGenerationId`.
      // NOTE: A better approach would be to have a "currentVersion" on Project that is separate from "AI Generations".
      // Let's update the WebsiteGeneration output for now as it's the source for Export.
      
      const generation = await WebsiteGeneration.findByIdAndUpdate(
        project.latestGenerationId,
        { output: content },
        { new: true }
      );

      res.json({ message: 'Content saved', generation });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }
}
