import { Request, Response } from 'express';
import { AIService } from '../services/AIService';
import { WebsiteBuilderService } from '../services/WebsiteBuilderService';
import { BillingService } from '../services/BillingService';
import Project from '../models/Project';
import WebsiteGeneration from '../models/WebsiteGeneration';
import User from '../models/User';

export class GenerationController {
  static async generate(req: Request, res: Response) {
    try {
      const { userId, prompt, type, model } = req.body;
      const COST = 10; // Fixed cost for generation

      // 1. Check credits
      const hasCredits = await BillingService.deductCredits(userId, COST, 'generation');
      if (!hasCredits) {
        return res.status(403).json({ error: 'Insufficient credits' });
      }

      // 1.5 Determine AI Model based on Subscription
      let selectedModel = model;
      if (!selectedModel) {
        const user = await User.findById(userId);
        if (user && user.subscriptionTier === 'pro') {
          selectedModel = 'gpt-4';
        } else {
          selectedModel = 'gpt-3.5';
        }
      }

      // 2. AI Generation
      const aiOutput = await AIService.generateWebsiteContent(prompt, selectedModel);

      // 3. Build Internal Structure
      const structure = WebsiteBuilderService.buildStructureFromAIOutput(aiOutput);

      // 4. Save Project
      const project = new Project({
        userId,
        name: aiOutput.branding.name,
        type: type || 'business',
        metadata: {
          style: 'modern',
          industry: type,
          colors: aiOutput.branding.colors
        }
      });
      await project.save();

      // 5. Save Generation Record
      const generation = new WebsiteGeneration({
        projectId: project._id,
        prompt,
        modelUsed: model || 'gpt',
        output: structure,
        cost: COST
      });
      await generation.save();

      // Link generation to project
      project.latestGenerationId = generation._id;
      await project.save();

      res.json({ project, structure });
    } catch (error: any) {
      console.error(error);
      res.status(500).json({ error: error.message });
    }
  }

  static async regenerateSection(req: Request, res: Response) {
    try {
      const { userId, projectId, sectionId, prompt, currentContent } = req.body;
      const COST = 2; // Mini cost for regeneration

      // 1. Check Project
      const project = await Project.findById(projectId);
      if (!project) return res.status(404).json({ error: 'Project not found' });

      // 2. Billing
      const hasCredits = await BillingService.deductCredits(userId, COST, 'generation');
      if (!hasCredits) {
        return res.status(403).json({ error: 'Insufficient credits' });
      }

      // 3. AI Regeneration
      const newContent = await AIService.regenerateSection(prompt, currentContent);

      // 4. Update Project Data (Optimistic update or fetching the full structure)
      // For this implementation, we return the new section content, and the frontend is responsible
      // for merging it and then calling `saveProjectContent`.
      // Alternatively, we could fetch the latest generation, find the section, replace it, and save.
      
      res.json({ sectionId, content: newContent });

    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }
}
