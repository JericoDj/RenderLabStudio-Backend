import { Request, Response } from 'express';
import Deployment from '../models/Deployment';
import Project from '../models/Project';
import { BillingService } from '../services/BillingService';

export class DeploymentController {
  static async deploy(req: Request, res: Response) {
    try {
      const { projectId, userId, type } = req.body;
      const COST = type === 'custom' ? 100 : 20;

      // 1. Check Project
      const project = await Project.findById(projectId);
      if (!project) return res.status(404).json({ error: 'Project not found' });

      // 2. Billing
      const hasCredits = await BillingService.deductCredits(userId, COST, 'deploy');
      if (!hasCredits) {
         return res.status(403).json({ error: 'Insufficient credits' });
      }

      // 3. Mock Deployment Process
      const deploymentUrl = `https://${project.name.toLowerCase().replace(/\s/g, '-')}.app.run`;
      
      const deployment = new Deployment({
          projectId,
          userId,
          url: deploymentUrl,
          type,
          status: 'live',
          version: '1.0.0'
      });
      await deployment.save();

      res.json({ deployment });

    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }
}
