import { Request, Response } from 'express';
import { ExportService } from '../services/ExportService';
import { BillingService } from '../services/BillingService';
import Project from '../models/Project';
import WebsiteGeneration from '../models/WebsiteGeneration';

export class ExportController {
  static async exportProject(req: Request, res: Response) {
    try {
      const { projectId, userId, format } = req.body;
      const COST = 50;

      // 1. Get Project Data
      const project = await Project.findById(projectId);
      if (!project) return res.status(404).json({ error: 'Project not found' });

      if (!project.latestGenerationId) return res.status(400).json({error: 'No content to export'});
      
      const generation = await WebsiteGeneration.findById(project.latestGenerationId);
      if (!generation) return res.status(404).json({error: 'Generation data not found'});

      // 2. Check credits
      const hasCredits = await BillingService.deductCredits(userId, COST, 'export');
      if (!hasCredits) {
        return res.status(403).json({ error: 'Insufficient credits' });
      }

      // 3. Generate Code
      const buffer = await ExportService.generateCode(generation.output, format);

      // 4. Send Response
      res.set('Content-Type', 'application/zip');
      res.set('Content-Disposition', `attachment; filename=${project.name}.zip`);
      res.send(buffer);

    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  }
}
