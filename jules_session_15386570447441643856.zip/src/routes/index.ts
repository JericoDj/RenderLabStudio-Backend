import { Router } from 'express';
import { GenerationController } from '../controllers/GenerationController';
import { ProjectController } from '../controllers/ProjectController';
import { ExportController } from '../controllers/ExportController';
import { DeploymentController } from '../controllers/DeploymentController';

const router = Router();

// Generation
router.post('/generate', GenerationController.generate);
router.post('/regenerate', GenerationController.regenerateSection);

// Project
router.get('/projects', ProjectController.listProjects);
router.get('/projects/:id', ProjectController.getProject);
router.patch('/projects/:id', ProjectController.updateProject);
router.put('/projects/:id/content', ProjectController.saveProjectContent);

// Export
router.post('/export', ExportController.exportProject);

// Deployment
router.post('/deploy', DeploymentController.deploy);

export default router;
