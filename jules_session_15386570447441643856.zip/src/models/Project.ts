import mongoose, { Schema, Document } from 'mongoose';

export interface IProject extends Document {
  userId: mongoose.Types.ObjectId;
  name: string;
  description?: string;
  type: string; // Portfolio, Agency, etc.
  latestGenerationId?: mongoose.Types.ObjectId;
  status: 'draft' | 'published';
  createdAt: Date;
  updatedAt: Date;
  metadata: {
    industry: string;
    style: string;
    colors: string[];
  };
}

const ProjectSchema: Schema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true },
  description: { type: String },
  type: { type: String, required: true },
  latestGenerationId: { type: Schema.Types.ObjectId, ref: 'WebsiteGeneration' },
  status: { type: String, enum: ['draft', 'published'], default: 'draft' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  metadata: {
    industry: { type: String },
    style: { type: String },
    colors: [{ type: String }],
  },
});

export default mongoose.model<IProject>('Project', ProjectSchema);
