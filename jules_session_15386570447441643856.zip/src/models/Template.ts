import mongoose, { Schema, Document } from 'mongoose';

export interface ITemplate extends Document {
  name: string;
  category: string;
  structure: any; // JSON structure
  thumbnailUrl: string;
  isPremium: boolean;
  createdAt: Date;
}

const TemplateSchema: Schema = new Schema({
  name: { type: String, required: true },
  category: { type: String, required: true },
  structure: { type: Schema.Types.Mixed, required: true },
  thumbnailUrl: { type: String },
  isPremium: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model<ITemplate>('Template', TemplateSchema);
