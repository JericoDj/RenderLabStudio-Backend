import mongoose, { Schema, Document } from 'mongoose';

export interface ICreditTransaction extends Document {
  userId: mongoose.Types.ObjectId;
  amount: number;
  type: 'deduction' | 'addition';
  reason: 'generation' | 'export' | 'deploy' | 'purchase' | 'subscription';
  createdAt: Date;
}

const CreditTransactionSchema: Schema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  amount: { type: Number, required: true },
  type: { type: String, enum: ['deduction', 'addition'], required: true },
  reason: { type: String, enum: ['generation', 'export', 'deploy', 'purchase', 'subscription'], required: true },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model<ICreditTransaction>('CreditTransaction', CreditTransactionSchema);
