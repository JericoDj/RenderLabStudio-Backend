import mongoose, { Schema, Document } from 'mongoose';

export interface IDeployment extends Document {
  projectId: mongoose.Types.ObjectId;
  userId: mongoose.Types.ObjectId;
  url: string;
  type: 'subdomain' | 'custom';
  status: 'deploying' | 'live' | 'failed';
  deployedAt: Date;
  version: string;
}

const DeploymentSchema: Schema = new Schema({
  projectId: { type: Schema.Types.ObjectId, ref: 'Project', required: true },
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  url: { type: String, required: true },
  type: { type: String, enum: ['subdomain', 'custom'], default: 'subdomain' },
  status: { type: String, enum: ['deploying', 'live', 'failed'], default: 'deploying' },
  deployedAt: { type: Date, default: Date.now },
  version: { type: String, required: true },
});

export default mongoose.model<IDeployment>('Deployment', DeploymentSchema);
