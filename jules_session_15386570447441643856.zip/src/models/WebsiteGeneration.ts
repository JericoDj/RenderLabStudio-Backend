import mongoose, { Schema, Document } from 'mongoose';

export interface IWebsiteGeneration extends Document {
  projectId: mongoose.Types.ObjectId;
  prompt: string;
  modelUsed: string; // GPT, Claude, etc.
  output: any; // JSON structure of the generated website
  cost: number;
  createdAt: Date;
}

const WebsiteGenerationSchema: Schema = new Schema({
  projectId: { type: Schema.Types.ObjectId, ref: 'Project', required: true },
  prompt: { type: String, required: true },
  modelUsed: { type: String, required: true },
  output: { type: Schema.Types.Mixed, required: true },
  cost: { type: Number, required: true },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model<IWebsiteGeneration>('WebsiteGeneration', WebsiteGenerationSchema);
