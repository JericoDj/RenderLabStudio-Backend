import mongoose, { Schema, Document } from 'mongoose';

export interface ISubscription extends Document {
  userId: mongoose.Types.ObjectId;
  plan: 'free' | 'pro' | 'enterprise';
  startDate: Date;
  endDate: Date;
  isActive: boolean;
  features: {
    exportEnabled: boolean;
    customDomain: boolean;
    privateProjects: boolean;
  };
}

const SubscriptionSchema: Schema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  plan: { type: String, enum: ['free', 'pro', 'enterprise'], required: true },
  startDate: { type: Date, default: Date.now },
  endDate: { type: Date },
  isActive: { type: Boolean, default: true },
  features: {
    exportEnabled: { type: Boolean, default: false },
    customDomain: { type: Boolean, default: false },
    privateProjects: { type: Boolean, default: false },
  },
});

export default mongoose.model<ISubscription>('Subscription', SubscriptionSchema);
