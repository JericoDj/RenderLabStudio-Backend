import mongoose, { Schema, Document } from 'mongoose';

export interface IAnalytics extends Document {
  projectId: mongoose.Types.ObjectId;
  views: number;
  uniqueVisitors: number;
  conversions: number;
  date: Date;
}

const AnalyticsSchema: Schema = new Schema({
  projectId: { type: Schema.Types.ObjectId, ref: 'Project', required: true },
  views: { type: Number, default: 0 },
  uniqueVisitors: { type: Number, default: 0 },
  conversions: { type: Number, default: 0 },
  date: { type: Date, default: Date.now }
});

export default mongoose.model<IAnalytics>('Analytics', AnalyticsSchema);
