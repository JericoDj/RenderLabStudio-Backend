import mongoose, { Schema, Document } from 'mongoose';

export interface IAsset extends Document {
  userId: mongoose.Types.ObjectId;
  projectId?: mongoose.Types.ObjectId;
  type: 'image' | 'video' | 'font';
  url: string;
  createdAt: Date;
}

const AssetSchema: Schema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  projectId: { type: Schema.Types.ObjectId, ref: 'Project' },
  type: { type: String, enum: ['image', 'video', 'font'], required: true },
  url: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model<IAsset>('Asset', AssetSchema);
