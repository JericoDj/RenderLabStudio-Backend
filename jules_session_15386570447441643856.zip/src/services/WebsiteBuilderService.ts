import { AIResponse } from './AIService';

// Internal representation of the website
export interface WebsiteStructure {
  meta: {
    title: string;
    description: string;
    favicon: string;
  };
  theme: {
    primaryColor: string;
    secondaryColor: string;
    fontFamily: string;
  };
  pages: Page[];
}

interface Page {
  id: string;
  slug: string;
  title: string;
  components: Component[];
}

interface Component {
  id: string;
  type: string; // hero, features, etc.
  props: any;
}

export class WebsiteBuilderService {
  static buildStructureFromAIOutput(aiOutput: AIResponse): WebsiteStructure {
    // Transform AI Output into internal robust structure
    const pages: Page[] = aiOutput.structure.pages.map((page, index) => ({
      id: `page-${index}`,
      slug: page.slug,
      title: page.name,
      components: page.sections.map((section, sIndex) => ({
        id: `comp-${index}-${sIndex}`,
        type: section.type,
        props: section.content
      }))
    }));

    return {
      meta: {
        title: aiOutput.branding.name,
        description: `Website for ${aiOutput.branding.name}`,
        favicon: "default.ico"
      },
      theme: {
        primaryColor: aiOutput.branding.colors[2] || '#000',
        secondaryColor: aiOutput.branding.colors[3] || '#fff',
        fontFamily: aiOutput.branding.typography.body
      },
      pages
    };
  }
}
