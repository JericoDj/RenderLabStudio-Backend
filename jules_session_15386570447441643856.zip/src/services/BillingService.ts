import CreditTransaction from '../models/CreditTransaction';
import User from '../models/User';
import mongoose from 'mongoose';

export class BillingService {
  static async deductCredits(userId: string, amount: number, reason: string): Promise<boolean> {
    const user = await User.findById(userId);
    if (!user) {
      throw new Error('User not found');
    }

    if (user.credits < amount) {
      return false; // Insufficient credits
    }

    user.credits -= amount;
    await user.save();

    const transaction = new CreditTransaction({
      userId: user._id,
      amount: amount,
      type: 'deduction',
      reason: reason
    });
    await transaction.save();

    return true;
  }

  static async addCredits(userId: string, amount: number, reason: string): Promise<void> {
    const user = await User.findById(userId);
    if (!user) throw new Error('User not found');

    user.credits += amount;
    await user.save();

    const transaction = new CreditTransaction({
      userId: user._id,
      amount: amount,
      type: 'addition',
      reason: reason
    });
    await transaction.save();
  }
}
