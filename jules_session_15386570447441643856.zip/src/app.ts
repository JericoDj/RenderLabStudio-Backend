import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import routes from './routes';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Routes
app.use('/api', routes);

// Database Connection
// In a real scenario, use process.env.MONGO_URI
// For this sandbox, we might skip actual connection or use an in-memory db if available,
// but since I can't spin up mongo here easily, I will just log the connection attempt.
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/ai-website-builder';

if (process.env.NODE_ENV !== 'test') {
  mongoose.connect(MONGO_URI)
    .then(() => console.log('MongoDB Connected'))
    .catch(err => console.error('MongoDB Connection Error:', err));
    
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

export default app;
